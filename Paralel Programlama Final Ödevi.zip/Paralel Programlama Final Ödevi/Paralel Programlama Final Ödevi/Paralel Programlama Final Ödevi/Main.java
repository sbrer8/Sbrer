import java.io.FileWriter;
import java.io.IOException;
import java.util.Scanner;

public class Main {
    public static void main(String[] args) {
        // İlk Thread  Kullanıcı bilgilerini Al
        Thread thread1 = new Thread(() -> {
            Scanner scanner = new Scanner(System.in);
            System.out.print("Kullanıcı Adı: ");
            String username = scanner.nextLine();
            System.out.print("Şifre: ");
            String password = scanner.nextLine();
            System.out.print("E-posta: ");
            String email = scanner.nextLine();

            try {
                FileWriter fileWriter = new FileWriter("c:\\io\\turgutozaluniversitesi\\person.txt");
                fileWriter.write("Kullanıcı Adı: " + username + "\n");
                fileWriter.write("Şifre: " + password + "\n");
                fileWriter.write("E-posta: " + email + "\n");
                fileWriter.close();
                System.out.println("Kullanıcı bilgileri kaydedildi.");
            } catch (IOException e) {
                e.printStackTrace();
            }
        });

        // İkinci Thread - Gizli Bilgileri Al
        Thread thread2 = new Thread(() -> {
            Scanner scanner = new Scanner(System.in);
            System.out.print("Gizli Bilgi: ");
            String secretInfo = scanner.nextLine();

            try {
                FileWriter fileWriter = new FileWriter("c:\\io\\turgutozaluniversitesi\\secret.txt");
                fileWriter.write("Gizli Bilgi: " + secretInfo + "\n");
                fileWriter.close();
                System.out.println("Gizli Bilgi Kaydedildi.");
            } catch (IOException e) {
                e.printStackTrace();
            }
        });

        // Threadleri çalıştır
        thread1.start();
        try {
            thread1.join(); // İlk threadin bitmesini bekler
        } catch (InterruptedException e) {
            e.printStackTrace();
        }
        thread2.start();
    }
}
//İlk threadin bitmesini beklemek için Join() metodu kullanılır.Bu yüzden ikinci thread ilkinin bitmesinden sonra çalışır.
// Yani binevi ilkinin bitmesi ikinciyi tetikler.