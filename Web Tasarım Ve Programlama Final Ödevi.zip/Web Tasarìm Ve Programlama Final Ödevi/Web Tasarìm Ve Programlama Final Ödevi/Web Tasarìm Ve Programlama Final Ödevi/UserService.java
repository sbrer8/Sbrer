import java.util.List;

public class UserService {

    public List<User> getAllUsers() {
        return null;
    }

}
