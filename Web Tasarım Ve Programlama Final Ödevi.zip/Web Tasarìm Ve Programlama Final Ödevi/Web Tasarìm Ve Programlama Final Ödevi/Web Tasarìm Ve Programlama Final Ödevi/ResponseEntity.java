import java.util.List;

public class ResponseEntity<T> {

    public static ResponseEntity<List<User>> ok(List<User> users) {
        return null;
    }

}
