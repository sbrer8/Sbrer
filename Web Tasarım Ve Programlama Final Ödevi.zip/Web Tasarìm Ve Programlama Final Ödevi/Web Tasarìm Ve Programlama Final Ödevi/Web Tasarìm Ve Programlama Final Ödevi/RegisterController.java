@RestController
public class RegisterController {

  // veritabanı bağlantısı için bir servis sınıfı ayarla
  @Autowired
  private UserService userService;

  // register bağlantısından post isteklerini al
  @PostMapping("/register")
  public ResponseEntity<String> register(@RequestBody User user) {
    return null;
    // Kullanıcı şifresi ile şifre onayı eşleşiyorsa}}
  }}