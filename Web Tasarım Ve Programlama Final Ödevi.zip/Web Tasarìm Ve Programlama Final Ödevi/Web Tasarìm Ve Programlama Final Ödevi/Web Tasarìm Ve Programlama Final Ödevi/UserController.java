﻿import java.util.List;

@RestController
public class UserController {

  // veritabanı bağlantısı için servis sınıfı ayarla
  @Autowired
  private UserService userService;

  // get komutlarını users adresınden al
  @GetMapping("/users")
  public ResponseEntity<List<User>> getUsers() {
    // veritabanından tüm kullanıcıları al
    List<User> users = userService.getAllUsers();
    // kullanıcı listesini çek
    return ResponseEntity.ok(users);
  }
}
