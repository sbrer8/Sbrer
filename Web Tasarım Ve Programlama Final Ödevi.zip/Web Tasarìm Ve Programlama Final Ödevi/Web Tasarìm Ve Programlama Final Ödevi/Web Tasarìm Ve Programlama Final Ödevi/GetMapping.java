
public @interface GetMapping {

    String value();

}
