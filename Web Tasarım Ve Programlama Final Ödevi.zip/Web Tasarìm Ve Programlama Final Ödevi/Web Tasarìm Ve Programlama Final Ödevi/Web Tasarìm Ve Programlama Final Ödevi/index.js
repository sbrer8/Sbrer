$(document).ready(function() {
    // form belirle
    var form = $("form");
    // olay yakala
    form.submit(function(event) {
      // varsayılan davranışı engelle
      event.preventDefault();
      // verileri formdan çek
      var firstName = $("#first-name").val();
      var email = $("#email").val();
      var password = $("#password").val();
      var confirmPassword = $("#confirm-password").val();
      // objeye veri yerleştir
      var data = {
        firstName: firstName,
        email: email,
        password: password,
        confirmPassword: confirmPassword
      };
      // spring apı"ya post isteği yolla
      $.post("https://spring-api.com/register", data, function(response) {
        // istek geçerliyse cevabı consol.log ile gönder
        console.log(response);
      });
    });
  });
  